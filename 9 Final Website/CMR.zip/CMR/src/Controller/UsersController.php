<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Core\Exception\Exception;
use Cake\Routing\Router;

class UsersController extends AppController
{

  
    
    public function beforeFilter(Event $event)
    {
        //parent::beforeFilter($event);
        $this->Auth->allow(['login'  , 'register' ,'recover','reset' ]);
        
    }
    
    public function isAuthorized($user)
    {
       return  true ;
    }
}