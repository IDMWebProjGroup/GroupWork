<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Core\Exception\Exception;
use Cake\Routing\Router;

class HomeController extends AppController
{

  
   public function index()
   {
   }	   
   
   public function beforeFilter(Event $event)
   {
        $this->Auth->allow();
   }
   
}