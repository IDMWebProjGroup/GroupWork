<?php
namespace App\Controller\Admin;
use Cake\ORM\TableRegistry;
use App\Controller\AppController;

/**
 * CmrData Controller
 *
 * @property \App\Model\Table\CmrDataTable $CmrData
 */
class CmrDataController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $staff_id = (empty($this->Auth->user()['staff_id']) ? 0 : $this->Auth->user()['staff_id']);
        
        $cmrs = TableRegistry::get("Cmrs")->find('list')->where([
            'cl_id' => $staff_id
        ])->select(['cmr_id'])->toArray();
        
        
        $this->paginate = [
            'contain' => ['Cmrs']
        ];
        
        $tmp = $this->CmrData->find();
        if(count($cmrs) > 0) 
            $tmp->where(['CmrData.cmr_id IN' => $cmrs]);
        
        if(is_numeric(@$_GET['filter_id']))
            $tmp->andWhere(['CmrData.cmr_id'=>$_GET['filter_id']]);
        
        $cmrData = $this->paginate($tmp);

        
        //List all available CMRs
        $cmrs_opt = TableRegistry::get("Cmrs")->find('all')->where([
            'cl_id' => $staff_id
        ])->select(['cmr_id','cmr_title'])->toArray();
        
        $cmrs = [''=>'All'];
        foreach($cmrs_opt as $c):
            $cmrs[$c['cmr_id']] = "{$c['cmr_title']} ({$c['cmr_id']})";
        endforeach;
        
        $this->set(compact('cmrData','cmrs'));
        $this->set('_serialize', ['cmrData']);
    }

    /**
     * View method
     *
     * @param string|null $id Cmr Data id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $cmrData = $this->CmrData->get($id, [
            'contain' => ['Cmrs']
        ]);

        $this->set('cmrData', $cmrData);
        $this->set('_serialize', ['cmrData']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $staff_id = $this->Auth->user()['staff_id'];
        
        $cmrs = TableRegistry::get("Cmrs")->find()->where([
            'cl_id' => $staff_id
        ])->all();
        
        if($cmrs->count() == 0)
        {
            $this->Flash->error('No CM Reports has been created yet. Please create a report first and then add data');
            $this->redirect(['action'=>'index' , 'controller'=>'Cmrs']);
        }
        
        $cmrData = $this->CmrData->newEntity();
        if ($this->request->is('post')) {
            $cmrData = $this->CmrData->patchEntity($cmrData, $this->request->data);
            if ($this->CmrData->save($cmrData)) {
                $this->Flash->success(__('The cmr data has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The cmr data could not be saved. Please, try again.'));
            }
        }
        
        
        $cmrs_list = [];
        foreach($cmrs as $c)
        {
            $cmrs_list[$c->cmr_id] = $c->cmr_title . " ({$c->cmr_id})";
        }
        
        $this->set(compact('cmrData', 'cmrs','cmrs_list'));
        $this->set('_serialize', ['cmrData']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Cmr Data id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $cmrData = $this->CmrData->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $cmrData = $this->CmrData->patchEntity($cmrData, $this->request->data);
            if ($this->CmrData->save($cmrData)) {
                $this->Flash->success(__('The cmr data has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The cmr data could not be saved. Please, try again.'));
            }
        }
       $cmrs = $this->CmrData->Cmrs->find('all', ['limit' => 200]);
        
        $cmrs_list = [];
        foreach($cmrs as $c)
        {
            $cmrs_list[$c->cmr_id] = $c->cmr_title . "({$c->cmr_id})";
        }
        
        $this->set(compact('cmrData', 'cmrs','cmrs_list'));
        $this->set('_serialize', ['cmrData']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Cmr Data id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $cmrData = $this->CmrData->get($id);
        if ($this->CmrData->delete($cmrData)) {
            $this->Flash->success(__('The cmr data has been deleted.'));
        } else {
            $this->Flash->error(__('The cmr data could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
