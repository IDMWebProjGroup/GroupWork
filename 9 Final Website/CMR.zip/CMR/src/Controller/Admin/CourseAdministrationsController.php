<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
/**
 * CourseAdministrations Controller
 *
 * @property \App\Model\Table\CourseAdministrationsTable $CourseAdministrations
 */
class CourseAdministrationsController extends AppController
{
    
     public function isAuthorized($user)
    {
        if($user['role'] == 'admin' || $user['role']=='pvc' || $user['role'] == 'dlt')
            return true;
        else
        {
            $action = $this->request->params['action'];
            
            
            if($action != 'index' && $action != 'view')
            {
                $this->Flash->error('You don\'t have permissions to perform that action.' );
                $this->redirect(['controller'=>'Home']);
            }
            else
                return true;
            
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Courses', 'CmStaffs', 'ClStaffs']
        ];
        $courseAdministrations = $this->paginate($this->CourseAdministrations);

        $this->set(compact('courseAdministrations'));
        $this->set('_serialize', ['courseAdministrations']);
    }

    /**
     * View method
     *
     * @param string|null $id Course Administration id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $courseAdministration = $this->CourseAdministrations->get($id, [
            'contain' => ['Courses', 'CmStaffs', 'ClStaffs']
        ]);

        $this->set('courseAdministration', $courseAdministration);
        $this->set('_serialize', ['courseAdministration']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $courseAdministration = $this->CourseAdministrations->newEntity();
        if ($this->request->is('post')) {
            $courseAdministration = $this->CourseAdministrations->patchEntity($courseAdministration, $this->request->data);
            if ($this->CourseAdministrations->save($courseAdministration)) {
                $this->Flash->success(__('The course administration has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The course administration could not be saved. Please, try again.'));
            }
        }
        $courses = $this->CourseAdministrations->Courses->find('all', ['limit' => 200]);
       
        $cmTable = TableRegistry::get('StaffLogins')->find()->where(['role'=> 'cm'])->contain(['Staffs']);
        $clTable = TableRegistry::get('StaffLogins')->find()->where(['role' =>'cl'])->contain(['Staffs']);
        
        $course_list =[];
        $cm_list=[];
        $cl_list=[];
        
        foreach($courses as $c){
            $course_list[$c->course_id] = $c->course_name . '(' . $c->course_code . ')';
        }
        
        foreach($clTable as $c)
        {
            $cl_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        foreach($cmTable as $c)
        {
            $cm_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        $this->set(compact('courseAdministration', 'courses', 'cls', 'cms','course_list','cm_list','cl_list'));
        $this->set('_serialize', ['courseAdministration']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Course Administration id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $courseAdministration = $this->CourseAdministrations->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $courseAdministration = $this->CourseAdministrations->patchEntity($courseAdministration, $this->request->data);
            if ($this->CourseAdministrations->save($courseAdministration)) {
                $this->Flash->success(__('The course administration has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The course administration could not be saved. Please, try again.'));
            }
        }
        $courses = $this->CourseAdministrations->Courses->find('all', ['limit' => 200]);
        $cmTable = TableRegistry::get('StaffLogins')->find()->where(['role'=> 'cm'])->contain(['Staffs']);
        $clTable = TableRegistry::get('StaffLogins')->find()->where(['role' =>'cl'])->contain(['Staffs']);
        
        $course_list =[];
        $cm_list=[];
        $cl_list=[];
        
        foreach($courses as $c){
            $course_list[$c->course_id] = $c->course_name . '(' . $c->course_code . ')';
        }
        
        foreach($clTable as $c)
        {
            $cl_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        foreach($cmTable as $c)
        {
            $cm_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        $this->set(compact('courseAdministration', 'courses', 'cls', 'cms','course_list','cm_list','cl_list'));
        $this->set('_serialize', ['courseAdministration']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Course Administration id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $courseAdministration = $this->CourseAdministrations->get($id);
        if ($this->CourseAdministrations->delete($courseAdministration)) {
            $this->Flash->success(__('The course administration has been deleted.'));
        } else {
            $this->Flash->error(__('The course administration could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
