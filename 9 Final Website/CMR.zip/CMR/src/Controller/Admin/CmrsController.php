<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\Routing\Router;
use Cake\ORM\TableRegistry;
/**
 * Cmrs Controller
 *
 * @property \App\Model\Table\CmrsTable $Cmrs
 */
class CmrsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => [ 'Courses', 'ClStaffs' ,'CmStaffs','Courses.Faculties']
        ];
        
        $ui =  $this->Auth->user();
        $user_id = $ui['user_id'];
        $staff_id = @$ui['staff_id'];
        
        $tmp = $this->Cmrs->find();
        
        //Filtering goes here
        $andClause = [];
        if(is_numeric(@$_GET['course_id']))
            $andClause['Cmrs.course_id']=$_GET['course_id'];
        
        if(is_numeric(@$_GET['year']))
            $andClause['Cmrs.year']=$_GET['year'];
        
       
       $orClause = ['Cmrs.cl_id'=>$staff_id,
                                'Cmrs.cm_id'=>$staff_id,
                                'Faculties.pvc_id'=>$staff_id,
                                'Faculties.dlt_id'=>$staff_id,
                                'Cmrs.dlt_approval'=>1,'Cmrs.cm_approval'=>1];
         //If admin get all CMRs
        //Adding always true statement
        if($ui['role'] == 'admin')
            $orClause['Cmrs.cmr_id >'] = 0;
        
        $tmp->where( ["OR" => $orClause]);
        
        if(count($andClause) > 0)
            $tmp =  $tmp->andWhere($andClause);               
        
        //Get Available Years
        $yearsResults = $this->Cmrs->find('all')->select('year')->distinct(['year'])->toArray();
        $years = [''=>'All'];
        
        foreach($yearsResults as $y)
            $years[$y['year']] = $y['year'];
            
        //Get exiting courses
        $courseResults = $this->Cmrs->Courses->find('all')->select(['course_id','course_code','course_name'])->
                            order(['course_name'])->toArray();
        $courses = [''=>'All'];
        
        foreach($courseResults as $c)
            $courses[$c['course_id']] = "{$c['course_name']} ({$c['course_code']})";
        
        
       
        
        $cmrs = $this->paginate($tmp->order(['year DESC','Courses.course_name'])  )                             ;

        $this->set(compact('cmrs','ui','years','courses'));
        $this->set('_serialize', ['cmrs']);
    }

    /**
     * View method
     *
     * @param string|null $id Cmr id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ui = $this->request->session()->read('ui');
        $cmr = $this->Cmrs->get($id, [
            'contain' => [ 'Courses', 'ClStaffs','CmStaffs','CmrData','Courses.Faculties','Courses.Faculties.DltStaffs',
                          'Courses.Faculties.Staffs']
        ]);
        
        
        //var_dump($cmr->cm_staff);exit;
        $this->set('cmr', $cmr);
        $this->set('ui',$ui);
        $this->set('_serialize', ['cmr']);
        
        
        $url = Router::url(['action'=>'view','prefix'=>'admin' ,'controller'=>'Cmrs' , $id]  , true);
        
        
        if(isset($this->request->data['cm_comment'])):
        
            $cmr->cm_comment = $this->request->data['cm_comment'];
            $cmr->cm_approval = $this->request->data['cm_approval'];
            if( $this->Cmrs->save($cmr) && $cmr->cm_approval):
            
                //Send mail to both staffs if Mail is approved
            
                $this->mailToLeaders($cmr->course->faculty->dlt_staff->email, $cmr->course->faculty->dlt_staff->last_name,
                                     $url,$cmr->cmr_title , $cmr->cm_comment);
                $this->mailToLeaders($cmr->course->faculty->staff->email, $cmr->course->faculty->staff->last_name,
                                     $url,$cmr->cmr_title, $cmr->cm_comment);
            endif;
            
        
        elseif(isset($this->request->data['dlt_comment'])):
            
            $cmr->dlt_comment = $this->request->data['dlt_comment'];
            $cmr->dlt_approval = $this->request->data['dlt_approval'];
            if($this->Cmrs->save($cmr) )
            {
                $state = "Approved";
                
                if(!$cmr->dlt_approval)
                    $state = "Rejected";
                
                $this->mailToAll($cmr->cm_staff->email, $cmr->cm_staff->last_name,
                                     $url,$cmr->cmr_title,$state,$cmr->dlt_comment);
                $this->mailToAll($cmr->cl_staff->email, $cmr->cl_staff->last_name,
                                     $url,$cmr->cmr_title,$state,$cmr->dlt_comment);
                $this->mailToAll($cmr->course->faculty->staff->email, $cmr->course->faculty->staff->last_name,
                                     $url,$cmr->cmr_title,$state,$cmr->dlt_comment);
                $this->mailToAll($cmr->course->faculty->dlt_staff->email, $cmr->course->faculty->dlt_staff->last_name,
                                     $url,$cmr->cmr_title,$state,$cmr->dlt_comment);
            }
            
            
        endif;
        
    }

    
    private function mailToAll($email , $name, $link,$title,$state,$comment)
    {
            $message = "<div>The CM Report has been finalised by the Director of Learning and Quality<br>
                        Current state of the project is <b>$state</b></div>
                        <div>Please check the following link to  view the report
                        <a href='$link'>$title</a><br/><cite>Comment : $comment
                        </cite></div><br/><br/><address>Zint University</address>";
            $reply = "info@zint.ac.lk";
            $header = "MIME-Version:1.0\r\nContent-type:text/html;charset=utf-8\r\n".
                            "From:$reply\r\nTo:$email\r\nReply-to:$reply\r\n";
            
            $message = "<!doctype html><html></head></head><body><b>Dear $name</b>, <br /><br/>"
            . $message . "</body></html>";
            mail( $email ,  'CM Report Approval' , $message ,$header);
            
    }
    
    private function mailToLeaders($email , $name, $link,$title,$comment)
    {
            $message = "An approval request for a CMR has been received. Please click on the following link to view the details.<br/>
                        <a href='$link'>$title</a><br/>
                            " . ((empty($comment)) ? '' : "<cite>Comment : $comment</cite>") .
                            "
                            <br/><br/><br/><address>Zint University</address>";
            $reply = "info@zint.ac.lk";
            $header = "MIME-Version:1.0\r\nContent-type:text/html;charset=utf-8\r\n".
                            "From:$reply\r\nTo:$email\r\nReply-to:$reply\r\n";
            
            $message = "<!doctype html><html></head></head><body><b>Dear $name</b>, <br /><br/>"
            . $message . "</body></html>";
            mail( $email ,  'CMR Approval Request' , $message ,$header);
            
    }
    
    public function submit()
    {
        if ($this->request->is('post')) {
             $cmr = $this->Cmrs->get($this->request->data['cmr_id'], [
            'contain' => [ 'CmStaffs' ]
        ]);
             
           
             $cmr->submitted_date = date('Y-m-d H:i:s');
             
             if($this->Cmrs->save($cmr))
             {
                $url = Router::url(['action'=>'view','prefix'=>'admin' ,'controller'=>'Cmrs' , $cmr->cmr_id]  , true);
                $this->mailToLeaders($cmr->cm_staff->email, $cmr->cm_staff->last_name,
                                     $url,$cmr->cmr_title,null);
                
             }
             else
             {
                die('Error occured');
             }
        }
        
        $this->redirect(['action'=>'index']);
    }
    
    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        $staff_id = $this->Auth->user()['staff_id'];
        
        $alloc_courses = TableRegistry::get('CourseAdministrations')->find()->contain(['Courses'])
        ->where(['cl_id'=>$staff_id])->all();
       
        if($alloc_courses ==null || $alloc_courses->count() == 0)
        {
            $this->Flash->error('No course has been allocated to you.');
            $this->redirect(['action'=>'index']);
        }
       
        
        $cmr = $this->Cmrs->newEntity();
        if ($this->request->is('post')) {
            $cmr = $this->Cmrs->patchEntity($cmr, $this->request->data);
            
            $alloc_courses = TableRegistry::get('CourseAdministrations')->find()->contain(['Courses'])
            ->where(['cl_id'=>$staff_id ,'year'=>$cmr->year])->all();
            
            //User trying to create a CMR for a year which he is been allocated
            if($alloc_courses ==null || $alloc_courses->count() == 0)
            {
                $this->Flash->error('You are not allowed to submit CMRs in this year');
                goto next;
            }
            
            //Get Course moderator and Course Leader
            $course = TableRegistry::get('CourseAdministrations')->find()->where(['course_id'=>$cmr->course_id,
             'year'=>$cmr->year])->first();
            
            if(!$course)
            {
                $this->Flash->error('Course is not registered for that year');
                goto next;
                                                                                  
            }
            $cmr->cl_id = $course->cl_id;
            $cmr->cm_id = $course->cm_id;
            
            if ($this->Cmrs->save($cmr)) {
                $this->Flash->success('The CMR has been saved.');
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error('The CMR could not be saved. Please, try again.');
            }
        }
        
        
        next:
        
        $cmrs = $this->Cmrs->Cmrs->find('list', ['limit' => 200]);
        
        $staffs = $this->Cmrs->CmStaffs->find('all', ['limit' => 200]);

        
        $course_list =[];
        foreach($alloc_courses as $c){
            $course_list[$c->course->course_id] = "{$c->course->course_name}({$c->course->course_code})";
        }
        
        $staff_list = [];
        foreach($staffs as $s){
            $staff_list[$s->staff_id] = "{$s->first_name} {$s->last_name}($s->staff_code)";
        }
        
        
        
        $this->set(compact(
            'staff_list','course_list'
        ));
        
        
        $this->set('user' , $this->Auth->user());
        $this->set(compact('cmr', 'cmrs', 'courses', 'staffs'));
        $this->set('_serialize', ['cmr']);
        
        
    }

    /**
     * Edit method
     *
     * @param string|null $id Cmr id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $staff_id = $this->Auth->user()['staff_id'];
        
        $cmr = $this->Cmrs->get($id, [
            'contain' => []
        ]);
        
        if($cmr->cl_id != $staff_id)
        {
            $this->Flash->error('You have no permission to edit this one.');
            $this->redirect(['action'=>'index']);
        }
        
        
        
        $alloc_courses = TableRegistry::get('CourseAdministrations')->find()->contain(['Courses'])
        ->where(['cl_id'=>$staff_id])->all();
       
        if($alloc_courses ==null || $alloc_courses->count() == 0)
        {
            $this->Flash->error('No course has been allocated to you.');
            $this->redirect(['action'=>'index']);
        }
        
        
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            $cmr = $this->Cmrs->patchEntity($cmr, $this->request->data);
            
            //Get Course moderator and Course Leader
            $course = TableRegistry::get('CourseAdministrations')->find()->where(['course_id'=>$cmr->course_id,
            'year'=>$cmr->year])->first();
            if(!$course)
            {
                $this->Flash->error('Course is not registered for that year');
                goto next;
                                                                                  
            }
                                                                                 
            $cmr->cl_id = $course->cl_id;
            $cmr->cm_id = $course->cm_id;
            
            if ($this->Cmrs->save($cmr)) {
                $this->Flash->success('The CMR has been saved.');
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error('The CMR could not be saved. Please, try again.');
            }
        }
        
        next:
        
        $cmrs = $this->Cmrs->Cmrs->find('list', ['limit' => 200]);
        $courses = $this->Cmrs->Courses->find('all', ['limit' => 200]);
        //$staffs = $this->Cmrs->CmStaffs->find('all', ['limit' => 200]);
        
         
        $course_list =[];
        foreach($alloc_courses as $c){
            $course_list[$c->course->course_id] = "{$c->course->course_name}({$c->course->course_code})";
        }
        
        /*$staff_list = [];
        foreach($staffs as $s){
            $staff_list[$s->staff_id] = "{$s->first_name} {$s->last_name}($s->staff_code)";
        }*/
        
             
        $this->set(compact(
            'course_list'
        ));
        
        
        $this->set(compact('cmr', 'cmrs', 'courses', 'staffs'));
        $this->set('_serialize', ['cmr']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Cmr id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $cmr = $this->Cmrs->get($id);
        if ($this->Cmrs->delete($cmr)) {
            $this->Flash->success(__('The cmr has been deleted.'));
        } else {
            $this->Flash->error(__('The cmr could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
