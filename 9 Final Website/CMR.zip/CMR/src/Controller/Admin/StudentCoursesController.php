<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * StudentCourses Controller
 *
 * @property \App\Model\Table\StudentCoursesTable $StudentCourses
 */
class StudentCoursesController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => [ 'Students', 'Courses']
        ];
        
        
        $tmp = $this->StudentCourses->find();
        
        $whereClause = [];
        
        //Filter by YEAR
        if(isset($_GET['year']) && is_numeric($_GET['year']))
            $whereClause['year'] = $_GET['year'];
        
        //Filter By Course
        if(isset($_GET['course_id']) && is_numeric($_GET['course_id']))
            $whereClause['StudentCourses.course_id'] = $_GET['course_id'];
        
        //Filter by Student code
        if(isset($_GET['student_code']) && preg_match("@^[\w]+$@",$_GET['student_code']))
            $whereClause['student_code'] = $_GET['student_code'];
        
        if(count($whereClause) > 0)
            $tmp->where($whereClause);
        
        
        
        $studentCourses = $this->paginate($tmp);
        
        //Get exiting courses
        $courseResults = $this->StudentCourses->Courses->find('all')->select(['course_id','course_code','course_name'])->
                            order(['course_name'])->toArray();
        $courses = [''=>'All'];
        
        foreach($courseResults as $c)
            $courses[$c['course_id']] = "{$c['course_name']} ({$c['course_code']})";
        
        
       

        $this->set(compact('studentCourses','courses'));
        $this->set('_serialize', ['studentCourses']);
    }

    /**
     * View method
     *
     * @param string|null $id Student Course id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $studentCourse = $this->StudentCourses->get($id, [
            'contain' => [ 'Students', 'Courses']
        ]);

        $this->set('studentCourse', $studentCourse);
        $this->set('_serialize', ['studentCourse']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $studentCourse = $this->StudentCourses->newEntity();
        if ($this->request->is('post')) {
            $studentCourse = $this->StudentCourses->patchEntity($studentCourse, $this->request->data);
            if ($this->StudentCourses->save($studentCourse)) {
                $this->Flash->success(__('The student course has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The student course could not be saved. Please, try again.'));
            }
        }
        $scs = $this->StudentCourses->find('list', ['limit' => 200]);
        $students = $this->StudentCourses->Students->find('all', ['limit' => 200]);
        $courses = $this->StudentCourses->Courses->find('all', ['limit' => 200]);
        
        $student_list = [];
        $course_list = [];
        
        foreach($students as $s){
            $student_list[$s->student_id] = $s->first_name . ' ' . $s->last_name . "({$s->student_code})";
        }
        
        foreach($courses as $c)
        {
            $course_list[$c->course_id] = $c->course_name . '(' . $c->course_code . ')';
        }
        
        $this->set(compact('studentCourse', 'scs', 'students', 'courses','student_list','course_list'));
        $this->set('_serialize', ['studentCourse']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Student Course id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $studentCourse = $this->StudentCourses->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $studentCourse = $this->StudentCourses->patchEntity($studentCourse, $this->request->data);
            if ($this->StudentCourses->save($studentCourse)) {
                $this->Flash->success(__('The student course has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The student course could not be saved. Please, try again.'));
            }
        }
        $scs = $this->StudentCourses->find('list', ['limit' => 200]);
        $students = $this->StudentCourses->Students->find('all', ['limit' => 200]);
        $courses = $this->StudentCourses->Courses->find('all', ['limit' => 200]);
        
        $student_list = [];
        $course_list = [];
        
        foreach($students as $s){
            $student_list[$s->student_id] = $s->first_name . ' ' . $s->last_name . "({$s->student_code})";
        }
        
        foreach($courses as $c)
        {
            $course_list[$c->course_id] = $c->course_name . '(' . $c->course_code . ')';
        }
        
        $this->set(compact('studentCourse', 'scs', 'students', 'courses','student_list','course_list'));
        $this->set('_serialize', ['studentCourse']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Student Course id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $studentCourse = $this->StudentCourses->get($id);
        if ($this->StudentCourses->delete($studentCourse)) {
            $this->Flash->success(__('The student course has been deleted.'));
        } else {
            $this->Flash->error(__('The student course could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
