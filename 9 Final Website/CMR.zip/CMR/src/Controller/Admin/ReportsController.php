<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class ReportsController extends AppController
{
    public function isAuthorized($user)
    {
        if($user['role'] == 'admin') //Only admin can access this area
        {
            return true;
        }
        else //Redirect to dashboard if you have no permissions
        {
            $this->Flash->error('You dont have permissions to access this area');
            $this->redirect(['controller'=>'Home']);
        }
        
    }

    /**
     * Lists all completed CMRs for each academic year
     */
    public function numCmr()
    {
        $connection = ConnectionManager::get('default');
        $sql = "SELECT count(cmr_id) as num , year FROM (SELECT * FROM cmrs WHERE cm_approval='1' AND dlt_approval='1')
        C GROUP BY C.year ORDER BY C.year ASC";
        
        $data = $connection->execute($sql)->fetchAll('assoc');
        
        $this->set('data' , $data);
        
    }

    /**
     *Find the courses that has got no course leaders and course moderators
     */
    public function noLeaders()
    {
        //Get default connection
        $connection = ConnectionManager::get('default');
        //Find lost courses
        $data = $connection->execute("SELECT A.* ,C.faculty_name, B.year FROM courses A LEFT OUTER JOIN course_administrations B ON
                                     A.course_id=B.course_id  INNER JOIN faculties C ON A.faculty_id = C.faculty_id WHERE B.year IS NULL")->fetchAll('assoc');

        $this->set('data' , $data);
        
    }
    
    /**
     *Find the courses which does not have any CMRs for the year
     **/
    public function noCmr()
    {
        $connection = ConnectionManager::get('default');
        
        $sql = "SELECT X.* , F.faculty_name,Y.course_code,Y.course_name, concat(CM.first_name,' ',CM.last_name) as cm_name,
            CM.staff_code as cm_code,concat(CL.first_name,' ',CL.last_name) as cl_name,
            CL.staff_code as cl_code FROM
            (SELECT CA.* FROM course_administrations CA LEFT OUTER JOIN cmrs C ON CA.course_id=C.course_id AND CA.year=C.year
            WHERE C.cmr_id IS NULL) X
            INNER JOIN courses Y ON X.course_id = Y.course_id INNER JOIN faculties F ON F.faculty_id = Y.faculty_id
            INNER JOIN staffs CM ON CM.staff_id = X.cm_id INNER JOIN staffs CL ON CL.staff_id = X.cl_id ORDER BY Y.course_name";
        $data = $connection->execute($sql)->fetchAll('assoc');   
        $this->set('data' , $data);
        
    }
    
    /**
     *List down all courses without CM or DLT approvals
     */
    public function noApprovals()
    {
       
       $connection = ConnectionManager::get('default');
       
       $sql = " SELECT CMR.*, concat(CM.first_name,' ',CM.last_name) as cm_name,CM.staff_code as cm_code,
                concat(CL.first_name,' ',CL.last_name) as cl_name,CL.staff_code as cl_code,
                concat(DLT.first_name,' ',DLT.last_name) as dlt_name,DLT.staff_code as dlt_code,DLT.staff_id as dlt_id,
                C.course_code,C.course_name,F.faculty_name,datediff(CURRENT_TIMESTAMP,CMR.submitted_date) as days_late FROM
                (SELECT * FROM cmrs WHERE (cm_approval IS NULL OR dlt_approval IS NULL) AND submitted_date IS NOT NULL) CMR
                INNER JOIN staffs  CM ON CM.staff_id = CMR.cm_id
                INNER JOIN staffs CL ON CL.staff_id = CMR.cl_id
                INNER JOIN courses C ON CMR.course_id = C.course_id
                INNER JOIN faculties F ON F.faculty_id=C.faculty_id
                INNER JOIN staffs DLT ON F.dlt_id = DLT.staff_id ORDER BY days_late DESC";
    
       
    
      $data = $connection->execute($sql)->fetchAll('assoc');
       $this->set('data',$data);
        
    }
    
    
    public function pctSubmitted()
    {
       $sql = "SELECT X.* , Y.num as approved_num FROM
                        (SELECT A.* , B.faculty_name FROM (SELECT count(*) as num ,F.faculty_id,CMR.year
                        FROM cmrs CMR INNER JOIN courses C ON CMR.course_id = C.course_id
                        INNER JOIN faculties F ON C.faculty_id = F.faculty_id group by F.faculty_id , CMR.year) A
                        INNER JOIN faculties B ON A.faculty_id = B.faculty_id) X
                        LEFT OUTER JOIN (SELECT A.* , B.faculty_name FROM (SELECT count(*) as num ,F.faculty_id,CMR.year
                        FROM (SELECT * FROM cmrs WHERE cm_approval ='1' AND dlt_approval='1') CMR INNER JOIN courses
                        C ON CMR.course_id = C.course_id INNER JOIN faculties F ON C.faculty_id = F.faculty_id
                        group by F.faculty_id , CMR.year) A
                        INNER JOIN faculties B ON A.faculty_id = B.faculty_id) Y
                        ON X.faculty_id = Y.faculty_id AND X.year = Y.year ORDER BY X.Year DESC, X.faculty_id";
        
        $connection = ConnectionManager::get('default');
        $this->set( 'data', $connection->execute($sql)->fetchAll('assoc'));
    }
    
    public function pctResponse()
    {
       $sql = "SELECT X.* , Y.num as approved_num FROM
                        (SELECT A.* , B.faculty_name FROM (SELECT count(*) as num ,F.faculty_id,CMR.year
                        FROM cmrs CMR INNER JOIN courses C ON CMR.course_id = C.course_id
                        INNER JOIN faculties F ON C.faculty_id = F.faculty_id group by F.faculty_id , CMR.year) A
                        INNER JOIN faculties B ON A.faculty_id = B.faculty_id) X
                        LEFT OUTER JOIN (SELECT A.* , B.faculty_name FROM (SELECT count(*) as num ,F.faculty_id,CMR.year
                        FROM (SELECT * FROM cmrs WHERE cm_comment IS NOT NULL OR dlt_comment IS NOT NULL) CMR INNER JOIN courses
                        C ON CMR.course_id = C.course_id INNER JOIN faculties F ON C.faculty_id = F.faculty_id
                        group by F.faculty_id , CMR.year) A
                        INNER JOIN faculties B ON A.faculty_id = B.faculty_id) Y
                        ON X.faculty_id = Y.faculty_id AND X.year = Y.year ORDER BY X.Year DESC, X.faculty_id";
        
        $connection = ConnectionManager::get('default');
        $this->set( 'data', $connection->execute($sql)->fetchAll('assoc'));
    }
	
	  public function index()
    {
        
    }
}

