<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
/**
 * Faculties Controller
 *
 * @property \App\Model\Table\FacultiesTable $Faculties
 */
class FacultiesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    
    public function isAuthorized($user)
    {
        if($user['role'] == 'dlt' || $user['role']=='pvc' || $user['role'] == 'admin')
            return true;
        else
        {
            $action = $this->request->params['action'];
            
            
            if($action != 'index' && $action != 'view')
            {
                $this->Flash->error('You don\'t have permissions to perform that action.' );
                $this->redirect(['controller'=>'Home']);
            }
            else
                return true;
            
        }
    }
    
    public function index()
    {
        $this->paginate = [
            'contain' => [ 'Staffs' , 'DltStaffs']
        ];
        $faculties = $this->paginate($this->Faculties);

        $this->set(compact('faculties'));
        $this->set('_serialize', ['faculties']);
    }

    /**
     * View method
     *
     * @param string|null $id Faculty id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $faculty = $this->Faculties->get($id, [
            'contain' => ['Staffs','DltStaffs']
        ]);

        $this->set('faculty', $faculty);
        $this->set('_serialize', ['faculty']);
        
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $faculty = $this->Faculties->newEntity();
        if ($this->request->is('post')) {
            $faculty = $this->Faculties->patchEntity($faculty, $this->request->data);
            if ($this->Faculties->save($faculty)) {
                $this->Flash->success(__('The faculty has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The faculty could not be saved. Please, try again.'));
            }
        }
        
        
        
        $faculties = $this->Faculties->Faculties->find('list', ['limit' => 200]);
        $staffs = $this->Faculties->Staffs->find('all', ['limit' => 200]);
        
        
        $pvcTable = TableRegistry::get('StaffLogins')->find()->where(['role'=> 'pvc'])->contain(['Staffs']);
        $dltTable = TableRegistry::get('StaffLogins')->find()->where(['role' =>'dlt'])->contain(['Staffs']);
        
        
        $pvc_list=[];
        $dlt_list=[];
        
        
        
        foreach($dltTable as $c)
        {
            $dlt_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        foreach($pvcTable as $c)
        {
            $pvc_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        
        $this->set(compact('faculty', 'faculties', 'staffs' ,
                           'pvc_list' , 'dlt_list'));
        $this->set('_serialize', ['faculty']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Faculty id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $faculty = $this->Faculties->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $faculty = $this->Faculties->patchEntity($faculty, $this->request->data);
            if ($this->Faculties->save($faculty)) {
                $this->Flash->success(__('The faculty has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The faculty could not be saved. Please, try again.'));
            }
        }
        $faculties = $this->Faculties->Faculties->find('list', ['limit' => 200]);
        $staffs = $this->Faculties->Staffs->find('all', ['limit' => 200]);
        
        
        $pvcTable = TableRegistry::get('StaffLogins')->find()->where(['role'=> 'pvc'])->contain(['Staffs']);
        $dltTable = TableRegistry::get('StaffLogins')->find()->where(['role' =>'dlt'])->contain(['Staffs']);
        
        
        $pvc_list=[];
        $dlt_list=[];
        
        
        
        foreach($dltTable as $c)
        {
            $dlt_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        foreach($pvcTable as $c)
        {
            $pvc_list[$c->staff->staff_id] = "{$c->staff->first_name} {$c->staff->last_name} ({$c->staff->staff_code})";
        }
        
        
        $this->set(compact('faculty', 'faculties', 'staffs' ,
                           'pvc_list' , 'dlt_list'));
        
        $this->set('_serialize', ['faculty']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Faculty id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $faculty = $this->Faculties->get($id);
        if ($this->Faculties->delete($faculty)) {
            $this->Flash->success(__('The faculty has been deleted.'));
        } else {
            $this->Flash->error(__('The faculty could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
