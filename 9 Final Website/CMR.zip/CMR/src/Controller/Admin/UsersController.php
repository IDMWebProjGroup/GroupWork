<?php
namespace App\Controller\Admin;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class UsersController extends AppController
{
	
	public function login()
	{
		
        if($this->request->is("post")):
        
            $users = TableRegistry::get('StaffLogins');
            
            $user = $users->find('all')->where(['StaffLogins.staff_code'=>$this->request->data['username'] ,
                                                'password'=> md5($this->request->data['password']) ])->contain(['Staffs'])->first();
            
            if(!$user)
            {
                $this->Flash->error("Username or Password is incorrect. Please try again.");
                goto next;
            }
            
           $ui = ['user_id' => $user->staff_code ,
                    'role'=>$user->role];
           
           if($user->has('staff')):
                $ui['full_name'] = $user->staff->first_name. ' ' . $user->staff->last_name;
                $ui['email'] = $user->staff->email;
                $ui['salutation'] = $user->staff->salutation;
                $ui['staff_id'] = $user->staff->staff_id;
           endif;
        
            $user->last_login = date('Y-m-d H:i:s');
            $users->save($user);
        
            $this->request->session()->write('ui', $ui);
            $this->Auth->setUser($ui);
        
            $this->redirect('/admin/home');
        
        endif;
        
        next:
        
	}
	
    public function logout()
    {
        $this->redirect($this->Auth->logout());
        $params = session_get_cookie_params();
        setcookie(session_name(),'',time()-3600, $params['path']);
        $this->request->session()->destroy();
    }
    
    
    //Change the password of current user
    public function changePassword()
    {
        
        $user = $this->Auth->user();
        
        if( empty($user) || $user['user_id'] == 'admin'):
            $this->redirect(['controller'=>'Home']);
        endif;
        
        if($this->request->is('post')):
        
            extract($_POST);
            $dbUsers = TableRegistry::get('StaffLogins');
            $dbUser =$dbUsers->find()->where(['staff_code'=>$user['user_id'] ,
                                                                  'password'=>md5($current_password) ])->first();
            if($dbUser == null):
                $this->Flash->error('Your current password is incorrect');
                goto next;
            endif;
            
            $new_password= trim($new_password);
            
            if($new_password != $confirm_password)
            {
                $this->Flash->error('New password doesn\'t match or may include invalid characters');
                goto next;
            }
           
            if(preg_match("@^[\w]{6,}$@" , $new_password) == false)
            {
                $this->Flash->error("Password should contain only letters and numbers , must be at least 6 characters long ");
                goto next;
            }
           
            $dbUser->password = md5($new_password);
            
            if($dbUsers->save($dbUser)):
                $this->Flash->success("Password changed");
                $this->redirect(['controller'=>'Home']);
            else:
                $this->Flash-error("Unable to save changes. Please try again.");
            endif;
            
        
        endif;
        
        next:
        
    }

}

