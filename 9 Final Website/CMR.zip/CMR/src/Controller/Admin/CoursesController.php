<?php
namespace App\Controller\Admin;

use App\Controller\AppController;

/**
 * Courses Controller
 *
 * @property \App\Model\Table\CoursesTable $Courses
 */
class CoursesController extends AppController
{

    public function isAuthorized($user)
    {
        if($user['role'] == 'dlt' || $user['role']=='pvc' || $user['role'] == 'admin')
            return true;
        else
        {
            $action = $this->request->params['action'];
            
            
            if($action != 'index' && $action != 'view')
            {
                $this->Flash->error('You don\'t have permissions to perform that action.' );
                $this->redirect(['controller'=>'Home']);
            }
            else
                return true;
            
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => [ 'Faculties']
        ];
        
        
        $tmp = $this->Courses->find();
        
        if(!empty($_GET['course_code']) && preg_match("@^[\w]+$@",$_GET['course_code']))
        {
            $tmp->where(['course_code LIKE' => $_GET['course_code'] . '%' ]);
        }
        
        if(!empty($_GET['course_name']) && preg_match("@^[\w]+$@",$_GET['course_name']) )
        {
            $tmp->where(['course_name LIKE' => '%' . $_GET['course_name'] . '%' ]);
        }
        
        
        $courses = $this->paginate($tmp);

        $this->set('courses',$tmp);
        $this->set('_serialize', ['courses']);
    }

    /**
     * View method
     *
     * @param string|null $id Course id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $course = $this->Courses->get($id, [
            'contain' => [ 'Faculties']
        ]);

        $this->set('course', $course);
        $this->set('_serialize', ['course']);
    }

    /**
     * Add method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $course = $this->Courses->newEntity();
        if ($this->request->is('post')) {
            $course = $this->Courses->patchEntity($course, $this->request->data);
            if ($this->Courses->save($course)) {
                $this->Flash->success(__('The course has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The course could not be saved. Please, try again.'));
            }
        }
        $courses = $this->Courses->Courses->find('list', ['limit' => 200]);
        $faculties = $this->Courses->Faculties->find('all', ['limit' => 200]);
        $options = [];
        
        foreach($faculties as $f):
            $options [$f->faculty_id] = $f->faculty_name;
        endforeach;
        
        $this->set(compact('course', 'courses', 'faculties','options'));
        $this->set('_serialize', ['course']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Course id.
     * @return \Cake\Network\Response|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $course = $this->Courses->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $course = $this->Courses->patchEntity($course, $this->request->data);
            if ($this->Courses->save($course)) {
                $this->Flash->success(__('The course has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The course could not be saved. Please, try again.'));
            }
        }
        $courses = $this->Courses->Courses->find('list', ['limit' => 200]);
        $faculties = $this->Courses->Faculties->find('all', ['limit' => 200]);
        $options = [];
        
        foreach($faculties as $f):
            $options [$f->faculty_id] = $f->faculty_name;
        endforeach;
        
        $this->set(compact('course', 'courses', 'faculties','options'));
        $this->set('_serialize', ['course']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Course id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $course = $this->Courses->get($id);
        if ($this->Courses->delete($course)) {
            $this->Flash->success(__('The course has been deleted.'));
        } else {
            $this->Flash->error(__('The course could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
