<?php
namespace App\Model\Table;

use App\Model\Entity\StudentCourse;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StudentCourses Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Scs
 * @property \Cake\ORM\Association\BelongsTo $Students
 * @property \Cake\ORM\Association\BelongsTo $Courses
 */
class StudentCoursesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('student_courses');
        $this->displayField('student_id');
        $this->primaryKey('sc_id');

        $this->belongsTo('StudentCourses', [
            'foreignKey' => 'sc_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Students', [
            'foreignKey' => 'student_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Courses', [
            'foreignKey' => 'course_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->requirePresence('year', 'create')
            ->notEmpty('year');

        $validator
            ->integer('cw1')
            ->allowEmpty('cw1');

        $validator
            ->integer('cw2')
            ->allowEmpty('cw2');

        $validator
            ->integer('cw3')
            ->allowEmpty('cw3');

        $validator
            ->integer('cw4')
            ->allowEmpty('cw4');

        $validator
            ->integer('exam')
            ->allowEmpty('exam');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        
        $rules->add($rules->existsIn(['student_id'], 'Students'));
        $rules->add($rules->existsIn(['course_id'], 'Courses'));
        return $rules;
    }
}
