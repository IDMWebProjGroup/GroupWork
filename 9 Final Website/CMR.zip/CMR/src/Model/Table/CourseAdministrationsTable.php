<?php
namespace App\Model\Table;

use App\Model\Entity\CourseAdministration;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * CourseAdministrations Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Cas
 * @property \Cake\ORM\Association\BelongsTo $Courses
 * @property \Cake\ORM\Association\BelongsTo $Staffs
 * @property \Cake\ORM\Association\BelongsTo $Staffs
 */
class CourseAdministrationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('course_administrations');
        $this->displayField('ca_id');
        $this->primaryKey(['ca_id']);

        $this->belongsTo('Cas', [
            'foreignKey' => 'ca_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Courses', [
            'foreignKey' => 'course_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('ClStaffs', [
            'foreignKey' => 'cl_id',
            'joinType' => 'INNER',
            'className' =>'Staffs'
        ]);
        $this->belongsTo('CmStaffs', [
            'foreignKey' => 'cm_id',
            'joinType' => 'INNER',
            'className' => 'Staffs'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->requirePresence('year', 'create')
            ->notEmpty('year');
        $validator->requirePresence('course_id','create')->notEmpty('course_id');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        
        $rules->add($rules->existsIn(['course_id'], 'Courses'));
        $rules->add($rules->existsIn(['cl_id'], 'ClStaffs'));
        $rules->add($rules->existsIn(['cm_id'], 'CmStaffs'));
        return $rules;
    }
}
