<?php
namespace App\Model\Table;

use App\Model\Entity\Cmr;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Cmrs Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Cmrs
 * @property \Cake\ORM\Association\BelongsTo $Courses
 * @property \Cake\ORM\Association\BelongsTo $Staffs
 * @property \Cake\ORM\Association\BelongsTo $Staffs
 * @property \Cake\ORM\Association\BelongsTo $Faculties
 */
class CmrsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('cmrs');
        $this->displayField('cmr_id');
        $this->primaryKey('cmr_id');

        $this->belongsTo('Cmrs', [
            'foreignKey' => 'cmr_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Courses', [
            'foreignKey' => 'course_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('CmStaffs', [
            'foreignKey' => 'cm_id',
            'joinType' => 'INNER',
            'className' =>'Staffs'
        ]);
        $this->belongsTo('ClStaffs', [
            'foreignKey' => 'cl_id',
            'joinType' => 'INNER',
            'className'=>'Staffs'
        ]);
       
       $this->hasMany('CmrData' , ['foreignKey' => 'cmr_id' , 'joinType'=>'LEFT' ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->requirePresence('year', 'create')
            ->notEmpty('year');

        $validator
            ->allowEmpty('cm_comment');

        $validator
            ->integer('cm_approval')
            ->allowEmpty('cm_approval');

        $validator
            ->integer('dlt_approval')
            ->allowEmpty('dlt_approval');

        $validator
            ->allowEmpty('dlt_comment');

        $validator
            ->dateTime('submitted_date')
            ->allowEmpty('submitted_date');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['course_id' , 'year']));
        $rules->add($rules->existsIn(['cmr_id'], 'Cmrs'));
        $rules->add($rules->existsIn(['course_id'], 'Courses'));
        $rules->add($rules->existsIn(['cm_id'], 'CmStaffs'));
        $rules->add($rules->existsIn(['cl_id'], 'ClStaffs'));

        return $rules;
    }
}
