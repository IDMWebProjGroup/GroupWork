<?php
namespace App\Model\Table;

use App\Model\Entity\CmrData;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * CmrData Model
 *
 * @property \Cake\ORM\Association\BelongsTo $Cmrs
 */
class CmrDataTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('cmr_data');
        $this->displayField('cmr_data_idx');
        $this->primaryKey('cmr_data_idx');

        $this->belongsTo('Cmrs', [
            'foreignKey' => 'cmr_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('cmr_data_idx')
            ->allowEmpty('cmr_data_idx', 'create');

        $validator
            ->requirePresence('cmr_data_title', 'create')
            ->notEmpty('cmr_data_title');

        $validator
            ->integer('val1')
            ->requirePresence('val1', 'create')
            ->notEmpty('val1');

        $validator
            ->integer('val2')
            ->requirePresence('val2', 'create')
            ->notEmpty('val2');

        $validator
            ->integer('val3')
            ->requirePresence('val3', 'create')
            ->notEmpty('val3');

        $validator
            ->integer('val4')
            ->requirePresence('val4', 'create')
            ->notEmpty('val4');
            
        $validator
            ->integer('average_marks');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['cmr_id'], 'Cmrs'));
        return $rules;
    }
}
