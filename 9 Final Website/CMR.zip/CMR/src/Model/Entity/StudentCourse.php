<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * StudentCourse Entity.
 *
 * @property int $sc_id
 * @property \App\Model\Entity\Sc $sc
 * @property int $student_id
 * @property \App\Model\Entity\Student $student
 * @property string $year
 * @property int $course_id
 * @property \App\Model\Entity\Course $course
 * @property int $cw1
 * @property int $cw2
 * @property int $cw3
 * @property int $cw4
 * @property int $exam
 */
class StudentCourse extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'sc_id' => false,
    ];
}
