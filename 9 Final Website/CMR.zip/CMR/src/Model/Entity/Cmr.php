<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Cmr Entity.
 *
 * @property int $cmr_id
 * @property \App\Model\Entity\Cmr $cmr
 * @property int $course_id
 * @property \App\Model\Entity\Course $course
 * @property string $year
 * @property int $cm_id
 * @property int $cl_id
 * @property \App\Model\Entity\Staff $staff
 * @property string $cm_comment
 * @property int $cm_approval
 * @property int $dlt_approval
 * @property string $dlt_comment
 * @property \Cake\I18n\Time $sumbitted_date
 * @property int $faculty_id
 * @property \App\Model\Entity\Faculty $faculty
 */
class Cmr extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        '*' => true,
        'cmr_id' => false,
    ];
}
