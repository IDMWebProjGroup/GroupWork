<?php 
namespace App\View\Helper;

use Cake\View\Helper;


class ImageHelper extends Helper
{
    public $helpers =['Url'];
    
    public function create($image_file)
    {
        $url = $this->Url->build($image_file);
        $small_url = str_replace('_normal.' ,'_small.' ,$url);
        $medium_url = str_replace('_normal.' ,'_medium.' ,$url);
        
        $img = "<img src='$medium_url' srcset='$small_url 480w, $medium_url 768w , $url 1000w' />"; 
        
        return $img;
    }
    
}